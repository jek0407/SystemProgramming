/* $begin stockserverimain */
#include "csapp.h"
#include <sys/select.h>

typedef struct item{ 
	int ID;
	int left_stock; 
	int price;
	struct item * right;
	struct item * left;
}Item;
Item *itemPtr;

typedef struct {
	int maxfd;
	fd_set read_set;
	fd_set ready_set;
	int nready;
	int maxi;
	int clientfd[FD_SETSIZE];
	rio_t clientrio[FD_SETSIZE];	
} pool;

void getStocktxt();
void updateStocktxt(int connfd);
void parseline(char* buf, char** argv);
Item* insert(Item *itemPtr, int ID, int left_stock, int price);
Item* fMin(Item* root);
Item* delete(Item* root, int ID);
Item* Search(Item* root, int target);
void inorderPrint(Item* root);
void inorderShow(Item* root, char* show);
void buystock(Item* flag, int count);
void sellstock(Item* flag, int count);
void init_pool(int listenfd, pool *p);
void add_client(int connfd, pool *p);
void check_clients(pool *p);

int main(int argc, char **argv) 
{
    int listenfd, connfd;
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
    char client_hostname[MAXLINE], client_port[MAXLINE]; 
    static pool pool;   
 
    if (argc != 2) { //잘못된 입력시 에러 출력
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(0);
    }

    getStocktxt();
    listenfd = Open_listenfd(argv[1]);
    init_pool(listenfd, &pool);

    while (1) {
	pool.ready_set = pool.read_set;
	pool.nready = Select(pool.maxfd+1, &pool.ready_set, NULL, NULL, NULL);

	if(FD_ISSET(listenfd, &pool.ready_set)){
		clientlen = sizeof(struct sockaddr_storage);
		connfd = Accept(listenfd, (SA *) &clientaddr, &clientlen);
		add_client(connfd, &pool);
		/*debug*/
		Getnameinfo((SA *) &clientaddr, clientlen, client_hostname, MAXLINE, client_port, MAXLINE, 0);
        	printf("Connected to (%s, %s)\n", client_hostname, client_port);
	}
	check_clients(&pool);
//	printf("Client login\n");
    }
    //exit(0);
}
/* $end stockserverimain */

void getStocktxt(){
    char text_linebuf[100];
    char cmdline[MAXLINE];
    char* arg[MAXLINE];
    int ID, left_stock, price;
    FILE *pFile = fopen("stock.txt", "r");
    while(!feof(pFile)){
	if(fgets(text_linebuf, 100, pFile)==NULL) break;
	strcpy(cmdline, text_linebuf);
	parseline(cmdline, arg);
	
	ID = atoi(arg[0]);
	left_stock = atoi(arg[1]);
	price = atoi(arg[2]);
	itemPtr = insert(itemPtr, ID, left_stock, price);
	memset(text_linebuf, '\0', 100);
    }
   fclose(pFile);
   printf("Stock Information\n");
   inorderPrint(itemPtr);
   printf("\n");
}

void updateStocktxt(int connfd){
    FILE *pFile = fopen("stock.txt", "w");
    char update[10000];	
    memset(update, '\0', 10000);
    inorderShow(itemPtr, update);
    printf("Client #%d exit\n", connfd-3);
    fputs(update, pFile);
    fclose(pFile);
    return;
}

void parseline(char* buf, char** argv)
{
	char* delim;         /* Points to first space delimiter */
	int argc;            /* Number of args */

	buf[strlen(buf) - 1] = ' ';  /* Replace trailing '\n' with space */
	while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

	/* Build the argv list */
	argc = 0;
	while ((delim = strchr(buf, ' '))) {
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
			buf++;
	}
	argv[argc] = NULL;

	return;
}

//insert binary tree
Item* insert(Item *itemPtr, int ID, int left_stock, int price){
	if(itemPtr == NULL){
		itemPtr = malloc(sizeof(Item));
		itemPtr->right = itemPtr->left = NULL;
		itemPtr->ID = ID;
		itemPtr->left_stock = left_stock;
		itemPtr->price = price;
		return itemPtr;
	}
	else{
		if(ID < itemPtr->ID) 
			itemPtr->left = insert(itemPtr->left, ID, left_stock, price);
		else 
			itemPtr->right = insert(itemPtr->right, ID, left_stock, price);
	}
	return itemPtr;
}

void inorderPrint(Item* root){
	if(root == NULL) return;
	
	inorderPrint(root->left);
	printf("%d %d %d\n", root->ID, root->left_stock, root->price);
	inorderPrint(root->right);	
}

void inorderShow(Item* root, char *show){
	char tmp[100];
	if(root == NULL) return;
	inorderShow(root->left, show);
	sprintf(tmp, "%d %d %d\n", root->ID, root->left_stock, root->price);
	strcat(show, tmp);
	inorderShow(root->right, show);
	return;
}

Item* Search(Item* root, int target){
//	printf("Search : %d\n", root->ID);
	if(root == NULL || root->ID == target)
		return root;
	if(root->ID < target)
		return Search(root->right, target);
	else
		return Search(root->left, target);
}

void buystock(Item* flag, int count){
	flag->left_stock -= count;	
}
void sellstock(Item* flag, int count){
	flag->left_stock += count;	
}
void init_pool(int listenfd, pool *p){
	int i;
	p->maxi = -1;
	for(i=0; i<FD_SETSIZE; i++) p->clientfd[i] = -1;

	p->maxfd = listenfd;
	FD_ZERO(&p->read_set);
	FD_SET(listenfd, &p->read_set);

}

void add_client(int connfd, pool *p){
	int i;
	p->nready--;
	for(i=0; i< FD_SETSIZE; i++)
		if(p->clientfd[i] <0){
			p->clientfd[i] = connfd;
			Rio_readinitb(&p->clientrio[i], connfd);
			FD_SET(connfd, &p->read_set);
			if(connfd > p->maxfd) p->maxfd = connfd;
			if(i>p->maxi) p->maxi = i;
			break;
		}
	if(i==FD_SETSIZE)
		app_error("add_client error : Too many clients");
}

void check_clients(pool *p){
    int i, connfd;
    char buf[MAXLINE];
    char msg[100], err_msg[100];
    int n, S_num, ID_client;
    rio_t rio;
    Item* flag;
	
    for(i=0; (i <= p->maxi) && (p->nready >0); i++){
	connfd = p->clientfd[i];
	rio = p->clientrio[i];
		
	if((connfd>0) && (FD_ISSET(connfd, &p->ready_set))) {
	    p->nready--;
	    if((n = Rio_readlineb(&rio, buf, MAXLINE))!=0){
	    
    	char cmdline[MAXLINE];
  	char* arg[MAXLINE];
	char show[10000];
	strcpy(cmdline, buf);
	parseline(cmdline, arg);
	//printf("debug : %s\n", arg[0]);
	memset(err_msg, '\0', 100);
	memset(msg, '\0', 100);
        if(strcmp(arg[0], "show")==0){
	    memset(show, '\0', 10000);
	    inorderShow(itemPtr, show);
	    Write(connfd, show, MAXLINE);
	    printf("Client #%d : Show request\n", connfd-3);
	}        
        else if(strcmp(arg[0], "buy")==0){
	   if(arg[1] == NULL || arg[2] == NULL){
		sprintf(err_msg, "Wrong input : Please enter Stock ID and Count.\n");
		Write(connfd, err_msg, 100);
	//	continue;
	   }
	   else{	 
	    	ID_client = atoi(arg[1]); S_num = atoi(arg[2]);
	   	flag = Search(itemPtr, ID_client);
		printf("Client #%d : Buy request %d %d\n", connfd-3, ID_client, S_num);
		
		if(flag == NULL) {	//printf("wrong Stock ID.\n");	
			sprintf(err_msg, "Check the Stock ID\n");
			Write(connfd, err_msg, 100);
	//		continue;
		}
		else{
			if(flag->left_stock >= S_num){
				buystock(flag, S_num);
				sprintf(msg, "[buy] success\n");
				Write(connfd, msg, 100);
	//			continue;
			}
			else {
				sprintf(err_msg, "Not enough left stock\n");
				Write(connfd, err_msg, 100);
	//			continue;
			}
		}
           }
	}
        else if(strcmp(arg[0], "sell")==0){
	   if(arg[1] == NULL || arg[2] == NULL){
		sprintf(err_msg, "Wrong input : Please enter Stock ID and Count.\n");
		Write(connfd, err_msg, 100);
	//	continue;
	   }
	   else{	 
	   	ID_client = atoi(arg[1]); S_num = atoi(arg[2]);
	   	flag = Search(itemPtr, ID_client);
		printf("Client #%d : Sell request %d %d\n", connfd-3, ID_client, S_num);
           	if(flag == NULL){
			sprintf(err_msg, "Check the Stock ID\n");
			Write(connfd, err_msg, 100);
	//		continue;
		}
          	else {
			sellstock(flag, S_num);
			sprintf(msg, "[sell] success\n");
			Write(connfd, msg, 100);
	//		continue;
		}
           }
	}
        else if(strcmp(arg[0], "exit")==0){
       	 	Rio_writen(connfd, buf, n);
//		break;
	}
	
	memset(arg[0], '\0', 10);
       // printf("server received %d bytes\n", n);
    }
	    else {			
			updateStocktxt(connfd);
        		Close(connfd);
			FD_CLR(connfd, &p->read_set);
			p->clientfd[i] = -1;
	    }
	}
    }
}
