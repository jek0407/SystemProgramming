#include "20171600.h"

int main() {
    char input[100] = "", command[100] = "", check[100] = "", mnemonic[30] = "", filename[30] = "";
    int address_start, address_end, value;
    
    char prog1[15], prog2[16], prog3[15], bp_clear[10];
    int count;
    
    // history linked list 구조
    hisHead = (hisNode*)malloc(sizeof(hisNode ));
    hisHead->next = NULL;
    hisTail = hisHead;
    
    // opcode.txt 파일 읽기
    if(readOpcodeFile() == 1)
        printf("Opcode File error.\n");
    
    while(1){
        // while loop 실행될때 마다 초기화
        memset(input, '\0', 100);
        memset(command, '\0', 100);
        memset(check, '\0', 100);
        
        printf("sicsim> ");
        fgets(input, 101, stdin);
        if(input[strlen(input)-1] != '\n')
            while(getchar() != '\n');
    
        if(input[0] == '\0' || input[0] == '\n') continue;
        sscanf(input, "%s %s", command, check);
        
        /*checkCommand return 값이
         1이면 단순 입력
         0이면 복잡한 입력 or 오류 입력
         */
        if (checkCommand(check)){// 명령어 단순 형식일때
            switch(commandNumber(command)){
                case 0 : help(); historyLink(input); break;
                case 1 : dir(); historyLink(input); break;
                case 2 : quit(); return 1;
                case 3 : historyLink(input); history(); break;
                case 4 : dump(-1, -1); historyLink(input); break; // du[mp] 형식
                case 7 : reset(); historyLink(input); break;
                case 9 : opcodelist(); historyLink(input); break;
                case 12: symbol(); historyLink(input); break;
                case 15: run(); historyLink(input); break;
                case 16: breakPoint(-1); historyLink(input); break;
                default : printf("wrong input.\n"); break; // 잘못된 명령어일때
            }
        }
        else{ // 명령어 복잡한 형식이거나 예외 형식일때
            char check2[100] = "";
            char comma_check;
            switch(commandNumber(command)){
                case 4 : // du[mp] [start], [end]
                    if(checkHexa(check, 0) || check[0] == '\0'){
                        if(check[0] == '\0'){ // du[mp] 형식일때
                            address_end = -1;
                            address_start = -1;
                        }
                        else {
                            memset(check, '\0', 100);
                            sscanf(input, "%s %x %s %s", command, &address_start, check, check2);
                            
                            if(check[0] == '\0' || (check[0] == ',' && check[1] != ',' && (isxdigit(check[1]) || isxdigit(check2[0])))){
                                if(check[0] == '\0'){ //du[mp] start 형식일때
                                    if(address_start<0 || address_start>0xfffff){
                                        printf("Wrong start address input.\n");
                                        break;
                                    }
                                    else address_end = -1;
                                }
                                else{ // du[mp] start, end
                                    memset(check, '\0', 100);
                                    sscanf(input, "%s %x %c %x %s", command, &address_start, &comma_check, &address_end, check);
                                    if(check[0] == '\0'){
                                        if( address_start > address_end || address_start<0 || address_end<0 || address_start > 0xfffff || address_end > 0xfffff) {
                                            printf("Wrong dump address input.\n");
                                            break;
                                        }
                                    }
                                    else {
                                        printf("Wrong input.\n");
                                        break;
                                    }
                                }
                            }
                            else {
                                printf("Wrong input.\n");
                                break;
                            }
                        }
                        historyLink(input);
                        dump(address_start, address_end);
                        break;
                    }
                    else{
                        printf("Wrong input.\n");
                        break;
                    }
                    
                case 5 : // e[dit] address, value
                    if(checkHexa(check,0)){
                        memset(check, '\0', 100);
                        sscanf(input, "%s %x %c %x %s", command, &address_start, &comma_check, &value, check);
                        if(check[0] != '\0'){
                            printf("wrong input.\n");
                            break;
                        }
                        else if(address_start<0 || address_start>0xfffff){
                            printf("wrong input.\n");
                            break;
                        }
                        else if(value<0 ||value>0xff){
                            printf("wrong input.\n");
                            break;
                        }
                        else {
                            historyLink(input);
                            edit(address_start, value);
                            break;
                        }
                    }
                    else {
                        printf("Wrong input.\n");
                        break;
                    }
                    
                case 6 : // f[ill] start, end, value
                    if(!checkHexa(check,-1)) {
                        printf("wrong input.\n");
                        break;
                    }
                    else{
                        memset(check, '\0', 100);
                        char comma_check2;
                        sscanf(input, "%s %x %c %x %c %s %s", command, &address_start, &comma_check, &address_end, &comma_check2, check2, check);
                        if (comma_check != ',' || comma_check2 != ',' || check[0] != '\0') {
                            printf("wrong input.\n");
                            break;
                        }
                        else if (address_start<0 || address_start>0xfffff || address_end<0 || address_end>0xfffff || address_start > address_end){
                            printf("wrong input.\n");
                            break;
                      }
                        else if (checkHexa(check2,0)==0) {
                            printf("wrong input.\n");
                            break;
                        }
                        sscanf(check2, "%x", &value);
                        historyLink(input);
                        fill(address_start, address_end, value);
                        break;
                    }
                case 8 : // opcode mnemonic
                    if(checkMnemonic(check) == 0){
                        printf("wrong input.\n");
                        break;
                    }
                    else{
                        memset(check, '\0', 100);
                        sscanf(input, "%s %s %s", command, mnemonic, check);
                        if(check[0] == '\0'){
                            if(opcode(mnemonic,1)) historyLink(input);
                            else printf("wrong input.\n");
                            break;
                        }
                        else {
                            printf("wrong input.\n");
                            break;
                        }
                    }
                case 10: //assemble
                    memset(filename, '\0', 30);
                    memset(check, '\0', 100);
                    sscanf(input, "%s %s %s", command, filename, check);
                    if(filename[0] == '\0' || check[0] != '\0') printf("Check filename input.\n");
                    assemble(filename);
                    historyLink(input);
                    break;
                case 11: //type
                    memset(filename, '\0', 30);
                    memset(check, '\0', 100);
                    sscanf(input, "%s %s %s", command, filename, check);
                    if(filename[0] == '\0' || check[0] != '\0') printf("Check filename input.\n");
                    type(filename);
                    historyLink(input);
                    break;
                case 13: //progaddr인 경우
                    memset(check, '\0', 100);
                    sscanf(input, "%s %s", command, check);
                    if (check[0] == '\0') { printf("Wrong input.\n");break; }
                    check[0]='\0';
                    sscanf(input, "%s %X %s", command, &prog_address, check);
                    if (check[0] != '\0') { printf("Wrong input.\n"); break; }
                    if (prog_address<0 || prog_address>0xfffff) { printf("Wrong address.\n"); break; }
                    historyLink(input);
                    break;

                case 14: //loader인 경우
                    memset(check, '\0', 100);
                    memset(prog1, '\0', 15);
                    memset(prog2, '\0', 15);
                    memset(prog3, '\0', 15);
                    freeEST();
                    sscanf(input, "%s %s %s %s %s", command, prog1, prog2, prog3, check);
                    if (check[0] != '\0') { printf("Wrong input-1\n"); break; }
                    if (prog1[0] == '\0') { printf("Wrong input-2\n"); break; }
                    else if (prog2[0] == '\0')  //loader filename1인 경우
                        count = 1;
                    else if (prog3[0] == '\0')  //loader filename1 filename2인 경우
                        count = 2;
                    else //loader filename1 filename2 filename3인 경우
                        count = 3;
                    if (loader(prog1, prog2, prog3, count) == -1) break; //로딩 중 에러 발생한 경우
                    historyLink(input); break;
                case 16: //bp인 경우
                    memset(check, '\0', 100);
                    sscanf(input, "%s %s %s", command, bp_clear, check);
                    if (check[0] != '\0') { printf("Wrong input-1\n"); break; }
                    else if (strcmp(bp_clear, "clear") == 0) { address_start = -2; } //bp clear인 경우
                    else { //bp address인 경우
                        sscanf(input, "%s %X", command, &address_start);
                        if (address_start<0 || address_start>0xfffff) { printf("Wrong address.\n"); break; }
                    }
                    breakPoint(address_start);
                    historyLink(input);break;
                default : printf("wrong input\n"); break;
            }
        }
    }
    return 0;
}

int readOpcodeFile(){
    int r_opcode, hash_value;
    char r_mnemonic[10], r_format[5];
    
    FILE* fp = fopen("opcode.txt", "r");
    hashNode* newNode;
    hashNode* tmp = (hashNode*)malloc(sizeof(hashNode));
    
    if(fp == NULL) return 1;
    
    while(fscanf(fp, "%x %s %s", &r_opcode, r_mnemonic, r_format) != EOF){
        newNode = (hashNode*)malloc(sizeof(hashNode));
        newNode->opcode = r_opcode;
        strcpy(newNode->mnemonic, r_mnemonic);
        strcpy(newNode->format, r_format);
        newNode->next = NULL;

        hash_value = findHashValue(newNode->mnemonic); //읽어들인 mnemonic의 hash값 찾기
        tmp = hashTable[hash_value];
        if(tmp == NULL){ //hash table의 처음이 비어있는경우
            hashTable[hash_value] = newNode;
        }
        else{ // 아닌경우
            while(tmp->next != NULL) tmp = tmp->next; //가장 끝에 새로운 노드 연결
            tmp->next = newNode;
        }
    }
    fclose(fp);
    
    return 0;
}

int commandNumber(char* command){
    if (strcmp(command, "h") == 0 || strcmp(command, "help") == 0) return 0;
    else if (strcmp(command, "d") == 0 || strcmp(command, "dir") == 0) return 1;
    else if (strcmp(command, "q") == 0 || strcmp(command, "quit") == 0) return 2;
    else if (strcmp(command, "hi") == 0 || strcmp(command, "history") == 0) return 3;
    else if (strcmp(command, "du") == 0 || strcmp(command, "dump") == 0) return 4;
    else if (strcmp(command, "e") == 0 || strcmp(command, "edit") == 0) return 5;
    else if (strcmp(command, "f") == 0 || strcmp(command, "fill") == 0) return 6;
    else if (strcmp(command, "reset") == 0) return 7;
    else if (strcmp(command, "opcode") == 0) return 8;
    else if (strcmp(command, "opcodelist") == 0) return 9;
    else if (strcmp(command, "assemble") == 0) return 10;
    else if (strcmp(command, "type") == 0) return 11;
    else if (strcmp(command, "symbol") == 0) return 12;
    else if (strcmp(command, "progaddr") == 0) return 13;
    else if (strcmp(command, "loader") == 0) return 14;
    else if (strcmp(command, "run") == 0) return 15;
    else if (strcmp(command, "bp") == 0) return 16;
    else return 17;
}

int checkCommand(char* check){
    for(int i=0; i<100; i++){
        if(check[i] != '\0'){
            return 0;
        }
    }
    return 1;
}

void help(){
    printf("h[elp]\nd[ir]\nq[uit]\nhi[story]\ndu[mp] [start, end]\ne[dit] address, value\nf[ill] start, end, value\nreset\nopcode mnemonics\nopcodelist\nassemble filename\ntype filename\nsymbol\n");
    printf("progaddr [address]\n");
    printf("loader [object filename1] [object filename2] [object filename3]\n");
    printf("run\n");
    printf("bp [adddress]\n");
}

void dir(){
    DIR* dp;
    struct dirent* entry = NULL;
    struct stat buf;
    int i=0;
    
    dp = opendir(".");
    if (dp == NULL) {
        printf("Dir open error.\n");
        return;
    }
    
    while ((entry = readdir(dp)) != NULL) {
        lstat(entry->d_name, &buf);
        if (S_ISDIR(buf.st_mode))
            printf("%20s/", entry->d_name);
        else if (S_IEXEC & buf.st_mode)
            printf("%20s*", entry->d_name);
        else //둘 다 아닌 경우
            printf("%20s", entry->d_name);
        i++;
        if(i%4==0) printf("\n");
    }
    printf("\n");
    closedir(dp);
    return;
}

void quit(){ //history list 비워주기
    hashNode* tmp = (hashNode*)malloc(sizeof(hashNode));
    
    if(hisHead == NULL) return;
    else if (hisHead->next == NULL) free(hisHead);
    else {
        hisTail = hisHead->next;
        while (hisTail != NULL) {
            free(hisHead);
            hisHead = hisTail;
            hisTail = hisTail->next;
        }
        free(hisHead);
    }
   
    for(int i=0; i<20; i++){
        if(hashTable[i] == NULL) continue; //원래 비어있는 경우에는 그냥 넘어간다.
        else if(hashTable[i]->next == NULL) free(hashTable[i]); //하나인 경우
        else{ //여러개인 경우
            tmp = hashTable[i]->next;
            while(tmp != NULL){
                free(hashTable[i]);
                hashTable[i] = tmp;
                tmp = tmp->next;
            } //끝까지 탐색 후
            free(hashTable[i]);  //free 한다.
        }
    }
}

void history(){
    hisNode* tmp = hisHead->next;
    for(int i=1; tmp != NULL; i++){
        printf("%d\t%s",i,tmp->input);
        tmp = tmp->next;
    }
}

void historyLink(char* input){
    char* begin;
    begin = input;
    
    while(*begin != '\0') { // left trim
        if(isspace(*begin))
            begin++;
        else{
            input = begin;
            break;
        }
    }
    
    hisNode* tmp = (hisNode*)malloc(sizeof(hisNode));
    strcpy(tmp->input, input);
    tmp->next = NULL;
    hisTail->next = tmp;
    hisTail = tmp;
}

void dump(int address_start, int address_end){
    int i, j, start, end;
    
    if(address_start == -1 && address_end == -1){
        start = address_current;
        end = start + 159;
        address_current = end + 1;
    }
    else if(address_end == -1){
        start = address_start;
        end = start + 159;
    }
    else{
        start = address_start;
        end = address_end;
    }
    
    if(end > 0xfffff)
        end = 0xfffff;
    
    for (i = (start/16) ; i <= (end/16) ; i++) {
        printf("%05X ", i*16);
        for (j = i*16 ; j<i*16+16 ; j++) {
            if (start<=j && j<=end) printf("%02X ", data[j]);
            else printf("   ");
        }
        printf("; ");
        for (j = i * 16; j<i * 16 + 16; j++) {
            if (data[j] < 32 || data[j]>126) printf(".");
            else if (start <= j && j <= end) printf("%c", data[j]);
            else printf(".");
        }
        printf("\n");
    }
}

int checkHexa(char* check, int flag){
    int i=0, flag2=0;
    
    if(!isxdigit(check[i])) return 0;

    for(i=1; i<100; i++){
        if((!isxdigit(check[i]) && check[i] != '\0' && check[i] != ',') || flag2+flag > 1) {
           // printf("debug!\n");
            return 0;
        }
        if(check[i] == ',') flag2++;
    }
  
    return 1;
}

void edit(int address, int value){
    data[address] = value;
}

void fill(int address_start, int address_end, int value){
    int i;
    for(i=address_start; i<= address_end; i++){
        data[i] = value;
    }
}
void reset(){
    int i;
    for (i = 0; i <= 0xfffff; i++) {
        data[i] = 0;
    }
}

int opcode(char* mnemonic, int key){
    int hash_value, flag=0;
    hashNode* tmp = (hashNode*)malloc(sizeof(hashNode));
    hash_value = findHashValue(mnemonic); //mnemonic의 hash값 찾기
    tmp = hashTable[hash_value];
    while (tmp != NULL) { //해당 줄의 끝까지 검사하면서 있으면 출력하고 flag 1로 설정
        if (strcmp(tmp->mnemonic, mnemonic) == 0) {
            flag = 1;
            if(key == 1) printf("opcode is %02X\n", tmp->opcode);
            return tmp->opcode;
        }
        tmp = tmp->next;
    }
    if (flag == 0) return 0; //opcode.txt에 없는 mnemonic인 경우
        
    return 1;
}

int checkMnemonic(char* check){
    int i;
    for(i=0; i<sizeof(check); i++){
        if((check[i]<'A' || check[i]>'Z') && check[i] != '\0') return 0;
    }
    return 1;
}

int findHashValue(char* mnemonic) {
    int i, value = 0;
    for (i = 0; i < strlen(mnemonic); i++) {
        value += mnemonic[i];
    }
    value %= 20;
    return value;
}

void opcodelist(){
    int i;
    hashNode* tmp = (hashNode*)malloc(sizeof(hashNode));

    for (i = 0; i < 20; i++) {
        printf("%d : ", i);
        tmp = hashTable[i];
        if(tmp == NULL){ //첫번째 칸이 비어있는 경우
            printf("\n"); continue;
        }
        while(tmp->next != NULL){ //아닌 경우
            printf("[%s, %02X] -> ", tmp->mnemonic, tmp->opcode);
            tmp = tmp->next;
        }
        printf("[%s, %02X]\n",tmp->mnemonic, tmp->opcode); // 그 줄의 끝까지 출력
    }
}

void assemble(char* filename){
    if(strcmp((filename+strlen(filename))-4, ".asm") != 0) {
        printf("Please input asm file.\n");
        return;
    }
    
    int i,j,k,m,cnt=1,tab=1;
    char instr[200], label[50] = "", mnemonic[50] = "", operand[50] = "";
    char* lst_file, * obj_file;
    FILE* fp, *lst_fp, *obj_fp;
    symbolNode* node;
    
    line_cnt = 0;
    for(i=0;i<20;i++){
        if(symbolTable[i]==NULL) continue;
        while(symbolTable[i] != NULL){
            node = symbolTable[i];
            symbolTable[i] = symbolTable[i]->next;
            free(node);
        }
    }
    
    fp = fopen(filename, "r");
    if(fp == NULL) {
        printf("There is no such a file.\n");
        return;
    }
    
    if(pass1(filename)){
        if(pass1(filename)>0) printf("Source file error on line #%d.\n",pass1(filename)*5);
        for(i=0;i<20;i++){
            if(symbolTable[i]==NULL) continue;
            while(symbolTable[i] != NULL){
                node = symbolTable[i];
                symbolTable[i] = symbolTable[i]->next;
                free(node);
            }
        }
        symbol_cnt = 0;
        return;
    }
    else if(pass2(filename)){
        if(pass1(filename)>0) printf("Source file error on line #%d.\n",pass2(filename)*5);
        for(i=0;i<20;i++){
            if(symbolTable[i]==NULL) continue;
            while(symbolTable[i] != NULL){
                node = symbolTable[i];
                symbolTable[i] = symbolTable[i]->next;
                free(node);
            }
        }
        symbol_cnt = 0; free(objectCode);
        return;
    }
    
    lst_file = (char*)malloc(sizeof(char)*1);
    obj_file = (char*)malloc(sizeof(char)*1);
    
    memset(lst_file, '\0', strlen(lst_file));
    memset(obj_file, '\0', strlen(lst_file));
    
    for(i=0;i<strlen(filename)-3;i++){
        lst_file[i] = filename[i];
        obj_file[i] = filename[i];
    }
    lst_file[i++] = 'l';
    lst_file[i++] = 's';
    lst_file[i++] = 't';
    lst_file[i] = '\0';
    i -= 3;
    obj_file[i++] = 'o';
    obj_file[i++] = 'b';
    obj_file[i++] = 'j';
    obj_file[i] = '\0';
    
    printf("output file : [%s], [%s]\n", lst_file, obj_file);
    
    lst_fp = fopen(lst_file, "w");
    
    for(i=1; i<=line_cnt; i++){
        fgets(instr, 500, fp);
        sscanf(instr, "%s %s %s", label, mnemonic, operand);
        
        fprintf(lst_fp, "%-5d", i*5);
        if(line[i]<0 || i == line_cnt) fprintf(lst_fp, "\t");
        else fprintf(lst_fp, "%04X", line[i]);
        fprintf(lst_fp, "\t");
        

        if(instr[strlen(instr)-1] == '\n') instr[strlen(instr)-1] = '\0';
        if(instr[0] == '\t'){
        fprintf(lst_fp, "%s", "    ");
        fprintf(lst_fp, "%-30s", instr+1);
       }
    else{
            fprintf(lst_fp, "%-30s", instr);
            tab = 0;
    }
        
        if(objectCode[i].format<0){
            fprintf(lst_fp,"\n");
            continue;
        }
        
        for(j=0;j<objectCode[i].format && objectCode[i].format < 300; j++)
        fprintf(lst_fp, "%02X", objectCode[i].name[j]);
        
        fprintf(lst_fp,"\n");
    }
    fclose(fp);
    fclose(lst_fp);
    
    obj_fp = fopen(obj_file, "w");
    fprintf(obj_fp, "H");
    if(pName[0] == '\0') fprintf(obj_fp,"\t");
    else fprintf(obj_fp,"%-6s", pName);
    fprintf(obj_fp, "%06X%06X\n", line[1], line[line_cnt]-line[1]);

    while(1){
        while(cnt<=line_cnt){
            if(objectCode[cnt].format<0 || line [cnt]<0) {
                cnt++;
                continue;
            }
            else break;
        }
        if(cnt>line_cnt) break;
        fprintf(obj_fp,"T%06X",line[cnt]);
        j=0;
        i=cnt;
        while(i<=line_cnt){
            if(objectCode[i].format == -2){
                i++;
                break;
            }
            else if(objectCode[i].format<0){
                i++;
                continue;
            }
            if(objectCode[i].format>0 && j+objectCode[i].format > 30 && j!=0) break;
            j += objectCode[i].format;
            i++;// check.
        }
        fprintf(obj_fp, "%02X", j);
        
        if(objectCode[cnt].format < 0) {
            fprintf(obj_fp, "\n");
            continue;
        }
        for(k=cnt;k<i;k++){
            if(objectCode[k].format<0) {
                continue;
            }
            for(m=0;m<objectCode[k].format;m++)
                if(objectCode[k].format < 32000) fprintf(obj_fp, "%02X", objectCode[k].name[m]);
        }
        cnt = i;
        fprintf(obj_fp, "\n");
    }
    
    for(i=0;i<line_cnt;i++){
        if(objectCode[i].format == 4 && objectCode[i].check!=10) fprintf(obj_fp,"M%06X%02X\n",line[i]+1,5);
    }
    
    for(i=1;i<line_cnt;i++){
        if(objectCode[i].format>0){
            fprintf(obj_fp,"E%06X\n", line[i]);
            break;
        }
    }
    fclose(obj_fp);
    free(line); free(objectCode); free(lst_file); free(obj_file);
}

int pass1(char* filename) {
    FILE* fp;
    char instr[200]; //asm파일 한 line에 있는 명령어들
    char str1[50] = "", str2[50] = "", str3[50]= ""; //뛰어쓰기로 구분되어 있는 한 단어
    int Loc=0,i=0,j=0,start_flag=0,end_flag=0,num;
    unsigned long len; //상수의 길이

    line = (int*)malloc(sizeof(int)*10000);

    fp = fopen(filename, "r");
    while( fgets(instr, 500,fp) != NULL ){
        i++;
        //Loc범위 체크, FFFF이하여야 함
        if(Loc >= 16*16*16*16) {
            return i;
        }
        //초기화
        memset(str1, '\0', 50);
        memset(str2, '\0', 50);
        memset(str3, '\0', 50);
     //   str1[0]='\0'; str2[0]='\0'; str3[0]='\0';
        
        sscanf(instr, "%s %s %s", str1, str2, str3);
        //START
        if(i==1 && (strcmp(str1,"START")==0 || strcmp(str2,"START")==0)){
            if(instr[0]=='\t') pName[0]='\0'; //프로그램 이름 지정되지 않은 경우
            else strcpy(pName,str1);
            if(str3[0] != '\0'){ //시작 주소가 지정되어 있는 경우
                sscanf(instr, "%s %s %X",str1,str2,&Loc);
            }
            else Loc = 0; //지정되지 않은 경우 0으로 초기화
            start_flag=1;
            line[i]=Loc;
        }
        else if(i==1 && (strcmp(str1,"START")!=0&&strcmp(str2,"START")!=0)){
            
            return i;//start로 시작하지 않은 경우
        }
        //END
        else if(strcmp(str1,"END")==0){
            line[i]=Loc; end_flag=1;
            break;
        }
        //comment
        else if(str1[0] == '.') {
            line[i] = -50;
            continue;
        }
        //나머지 경우
        else {
            line[i] = Loc;
            if(instr[0] != '\t' && instr[0] != ' '){ //lable이 있는 경우
                //Symbol table에 lable이름과 Loc저장
                if(symbolAdd(str1,Loc)<0){
                    
                    return i;
                }//중복 or 길이초과
                strcpy(str1,str2);
                strcpy(str2,str3);
            }
            //BYTE
            if(strcmp(str1,"BYTE")==0) {
                //에러 체크(C,X만 가능, 형식 확인)
                if(str2[0]=='C' && str2[1]=='\''){ //char인 경우
                    len = strlen(str2);
                    if(str2[len-1]!='\''){      return i;}
                    for(j=2;j<len-1;j++){ //char로만 입력되었는지 확인
                        if( str2[j]<'A' || str2[j]>'Z') { return i;}
                    }
                    Loc += (len-3);
                }
                else if(str2[0]=='X' && str2[1]==39){ //hexa인 경우
                    len = strlen(str2);
                    if(str2[len-1]!='\''){ return i;}
                    else if((len-3)%2 != 0){ //X뒤에는 짝수개의 숫자가 와야한다.
                        
                        return i;
                    }
                    for(j=2;j<len-1;j++){ //16진수로만 입력되었는지 확인
                        if( (str2[j]<'0' || str2[j]>'9') && (str2[j]<'A' || str2[j]>'F')){
                            
                            return i;
                        }
                    }
                    Loc += ((len-3)/2);
                }
                else{  return i;}
            }
            //WORD
            else if(strcmp(str1,"WORD")==0) {
                len = strlen(str2);
                for(j=0;j<len;j++){
                    if( str2[j]<'0' || str2[j]>'9') {  return i;}
                }
                Loc += 3;
            }
            //RESB
            else if(strcmp(str1,"RESB")==0) {
                len = strlen(str2);
                for(j=0;j<len;j++){
                    if( str2[j]<'0' || str2[j]>'9') { return i;}
                }
                sscanf(str2,"%d",&num);
                Loc += num;
            }
            //RESW
            else if(strcmp(str1,"RESW")==0)    {
                len = strlen(str2);
                for(j=0;j<len;j++){
                    if( str2[j]<'0' || str2[j]>'9') { return i;}
                }
                sscanf(str2,"%d",&num);
                Loc += (num*3);
            }
            //BASE
            else if(strcmp(str1,"BASE")==0){line[i]=-50; continue;} //주석과 마찬가지
            //나머지 경우(intruction)
            else{
                Loc+= findFormat(str1);
                if(findFormat(str1) == -1){  return i;}
            }
        }
    }
    if(start_flag==0){
        printf("No start label.\n");
        return -1;
    }
    else if(end_flag==0){
        printf("No end label.\n");
        return -1;
    }
    line_cnt = i;
    return 0;
}

int pass2(char* filename) {
    FILE* fp;
    char instr[200];
    int i,j,a,b,pc=0,base=0,opco,format;
    unsigned long len;
    char str1[50] = "", str2[50]= "", str3[50] = "", str4[50] = "";
    Opr op;
    //int comma_flag;

    fp = fopen(filename, "r");
    objectCode = (objectNode*)malloc(sizeof(objectNode)*(line_cnt+1));
    memset(objectCode, 0, sizeof(objectNode));

    for(i=1;i<=line_cnt;i++){
        //comma_flag=0;
        memset(str1, '\0', 50);
        memset(str2, '\0', 50);
        memset(str3, '\0', 50);
        memset(str4, '\0', 50);
      //  str1[0]='\0'; str2[0]='\0'; str3[0]='\0'; str4[0]='\0';
        fgets(instr,500,fp);
        pc = line[i+1];
        if(pc<0){ //다음줄이 주석이나 BASE인 경우 뛰어넘도록 설정
            j=i;
            while(pc<0){
                j++;
                pc=line[j];
            }
        }
        sscanf(instr, "%s %s %s %s", str1, str2, str3, str4);
        if(instr[0] != '\t' && instr[0]!=' '){//lable이 있는 경우
            strcpy(str1,str2);
            strcpy(str2,str3);
            strcpy(str3,str4);
        }
        if(strcmp(str1,"START")==0){objectCode[i].format=0;}
        else if(strcmp(str1,"BASE" )==0){
            objectCode[i].format = -1;
            base = findSymbol(str2);
            if (base<0)  return i;
        }
        else if(strcmp(str1,"END" )==0) break;
        else if(strcmp(str1,"RESW")==0 || strcmp(str1,"RESB")==0){
            objectCode[i].format = -2;
        }
        else if(strcmp(str1,"BYTE")==0 || strcmp(str1,"WORD")==0){
            if(str2[0]=='C'){ //BYTE인 경우중 C입력시
                a=0;
                len = strlen(str2);
                for(j=2;j<len-1;j++){
                    objectCode[i].name[a++]=str2[j];
                }
                objectCode[i].format=(int)len-3;
            }
            else if(str2[0]=='X'){ //BYTE인 경우 중 X입력시
                len = strlen(str2);
                sscanf(str2+2,"%X",&a);
                if(len <= 5)
                    objectCode[i].name[0]=a;
                else{
                    objectCode[i].name[0]=(a>>8)&255;
                    objectCode[i].name[1]=(a)&255;
                }
                    objectCode[i].format=(int)(len-3)/2;
            }
            else{ //WORD인 경우
                sscanf(str2,"%d",&a);
                objectCode[i].name[0]=(a>>16)&255;
                objectCode[i].name[1]=(a>>8)&255;
                objectCode[i].name[2]=(a)&255;
                objectCode[i].format=3;
            }
        }
        else{ //instruction인 경우
            format = findFormat(str1); opco = opcode(str1,0);
            if(format==1){
                if(str2[0] != '\0') return i;
                objectCode[i].name[0]=opco;
                objectCode[i].format=1;
            }
            else if(format==2){
                objectCode[i].name[0]=opco; objectCode[i].format=format;
                if(str2[0]=='\0') return i;
                else if(str3[0]=='\0'){ //인자 하나
                    a = findReg(str2);
                    if(a==-1) return i;
                    objectCode[i].name[1]=a<<4;
                }
                else if(str4[0]=='\0'){    //인자 둘
                    len=strlen(str2);
                    if(str2[len-1]==',') str2[len-1]='\0';
                    else return i;
                    a = findReg(str2);
                    b = findReg(str3);
                    if(a==-1 || b==-1) return i;
                    objectCode[i].name[1]=(a<<4)+b;
                }
                else return i;
            }
            else if(format==3 || format==4){
                objectCode[i].name[0]=opco; objectCode[i].format=format;
                if(str2[0]=='\0'){ //인자 없는 경우
                    objectCode[i].name[0]+=3;
                    objectCode[i].name[1]= objectCode[i].name[2]= objectCode[i].name[3]=0;
                }
                else if(str3[0]=='\0'){ //배열 사용하지 않는 경우
                    op = operandMode(str2);
                    if(op.mode == -1|| op.mode==0) return i;
                    if(format==3){
                        if(op.mode==4){ //#상수
                            if(op.addr>=16*16*16) return i;
                            objectCode[i].name[0] += 1;
                            objectCode[i].name[1]=op.addr/(16*16);
                            objectCode[i].name[2]=op.addr%(16*16);
                            objectCode[i].check=10; //obj_file 만들때 사용
                        }
                        else{
                            objectCode[i].name[0] += op.mode;
                            if( op.addr >= pc-2048 && op.addr <= pc+2047){ //pc 사용가능
                                a = op.addr-pc;
                                objectCode[i].name[1]=(1<<5)+(15&(a>>8));
                                objectCode[i].name[2]=(255&a);
                            }
                            else if(op.addr>=base&&op.addr<=base+4095){ //base 사용가능
                                a = op.addr-base;
                                objectCode[i].name[1]=(1<<6)+(15&(a/256));
                                objectCode[i].name[2]=(a%256);
                            }
                            else return i;
                        }
                    }
                    else if(format==4){
                        if(op.mode==4){ //#상수
                            objectCode[i].name[0] += 1;
                            objectCode[i].name[1]=(1<<4)+op.addr/(16*16*16*16);
                            objectCode[i].name[2]=(255&(op.addr>>8));
                            objectCode[i].name[3]=(255&(op.addr));
                            objectCode[i].check=10;
                        }
                        else{
                            objectCode[i].name[0] += op.mode;
                            objectCode[i].name[1]=(1<<4)+(15&(op.addr>>16));
                            objectCode[i].name[2]=(255&(op.addr>>8));
                            objectCode[i].name[3]=(255&(op.addr));
                        }
                    }
                }
                else if(str4[0]=='\0'){ //배열 사용
                    len=strlen(str2);
                    if(str2[len-1]==',') str2[len-1]='\0';
                    else return i;
                    op = operandMode(str2);
                    if(strcmp(str3,"X")!=0) return i;
                    if(op.mode==-1 || op.mode==0)  return i;
                    
                    if(format==3){
                        if(op.mode==4){ //#상수
                            if(op.addr>0xfff)  return i;
                            objectCode[i].name[0] += 1;
                            objectCode[i].name[1]=(1<<7)+op.addr/(16*16);
                            objectCode[i].name[2]=op.addr%(16*16);
                        }
                        else{
                            objectCode[i].name[0] += op.mode;
                            if( op.addr >= pc-2048 && op.addr <= pc+2047){ //pc 사용가능
                                a = op.addr-pc;
                                objectCode[i].name[1]=(1<<5)+(1<<7)+(15&(a>>8));
                                objectCode[i].name[2]=(255&a);
                            }
                            else if(op.addr>=base && op.addr<=base+4095){
                                a = op.addr-base;
                                objectCode[i].name[1]=(1<<6)+(1<<7)+(a/256);
                                objectCode[i].name[2]=(a%256);
                            }
                            else return i;
                        }
                    }
                    else if(format==4){
                        if(op.mode==3) {
                            objectCode[i].name[0] += op.mode;
                            objectCode[i].name[1]=(1<<4)+(1<<7)+(15&(op.addr>>16));
                            objectCode[i].name[2]=(255&(op.addr>>8));
                            objectCode[i].name[3]=(255&(op.addr));
                        }
                        else return i;
                    }
                }
                else return i;
            }
        }
    }
    fclose(fp);
    return 0;
}

int symbolAdd(char* str, int Loc){
    symbolNode* tmp;
    symbolNode* new = (symbolNode*)malloc(sizeof(symbolNode));
    int hash_value = findHashValue(str);

    if((int)strlen(str)>6)
        return -2;
    strcpy(new->name,str); new->address = Loc;
    new->next = NULL;

    if(symbolTable[hash_value] == NULL)
        symbolTable[hash_value] = new;
    else{
        tmp = symbolTable[hash_value];
        while(1){
            if(strcmp(tmp->name,new->name)==0) return -1;
            if(tmp->next == NULL) break;
            else tmp = tmp->next;
        }
        tmp->next = new;
    }
    symbol_cnt++;
    return 0;
}

void type(char* filename){
    char c;
    FILE* fp = fopen(filename,"r");
    if(fp==NULL){
        printf("File open error.\n");
        return;
    }
    while(fscanf(fp, "%c",&c) != EOF){
        printf("%c",c);
    }
    fclose(fp);
    printf("\n");
    return;
}

void symbol(void){
    int i,j;
    symbolNode* node;
    char** order; //심볼과
    int* num;      //Loc저장할 변수
    int* d;
    int count=0;
    int tmp;

    if(symbol_cnt==0) return;
    //symbol 개수만큼 동적 할당
    order = (char**)malloc(sizeof(char*)*symbol_cnt);
    d = (int*)malloc(sizeof(int)*symbol_cnt);
    for(i=0;i<symbol_cnt;i++){
        order[i] = (char*)malloc(sizeof(char)*10);
        d[i] = i;
    }
    num = (int*)malloc(sizeof(int)*symbol_cnt);
    //복사
    for(i=0;i<20;i++){
        node = symbolTable[i];
        while(node != NULL){
            strcpy(order[count],node->name);
            num[count] = node->address;
            count++;
            node = node->next;
        }
    }
    //알파벳순 오름차순 정렬
    for(i=0;i<count;i++){
        for(j=i+1;j<count;j++){
            if(strcmp(order[d[i]],order[d[j]])>=0){
                tmp = d[i]; d[i] = d[j]; d[j] = tmp;
            }
        }
    }
    //출력
    for(i=0;i<count;i++){
        printf("\t%-7s\t%04X\n",order[d[i]],num[d[i]]);
    }
    //free
    for(i=0; i<symbol_cnt; i++){
        free(order[i]);
    }
    free(order); free(num); free(d);
}

Opr operandMode(char* str){ //operand의 mode와 lable인 경우 그 lable의 주소 return
    Opr operand;
    int a,b;
    
    operand.mode=0; operand.addr=0;
    a = findReg(str);
    if(a != -1){
        operand.mode=0; operand.addr=a;
        return operand;
    }
    else if(str[0]=='#'){
        operand.mode=1;
        sscanf(str,"#%s",str);
    }
    else if(str[0]=='@'){
        operand.mode=2;
        sscanf(str,"@%s",str);
    }
    else operand.mode=3;

    a = findSymbol(str);
    if(a==-1){
        if(operand.mode==1){
            sscanf(str,"%d",&b);
            if(b<0||b>0xfffff){operand.mode=-1; return operand;}
            operand.addr=b; operand.mode=4;
            return operand;
        }
        operand.mode=-1; return operand;
    }
    else operand.addr = a;
    return operand;
}

int findReg(char* str){
    if(strcmp(str,"A")==0)return 0;
    else if(strcmp(str,"X")==0)return 1;
    else if(strcmp(str,"L")==0)return 2;
    else if(strcmp(str,"PC")==0)return 8;
    else if(strcmp(str,"SW")==0)return 9;
    else if(strcmp(str,"B")==0)return 3;
    else if(strcmp(str,"S")==0)return 4;
    else if(strcmp(str,"T")==0)return 5;
    else if(strcmp(str,"F")==0)return 6;
    else return -1;
}

int findSymbol(char* str){
    int hash_value = findHashValue(str);
    symbolNode* node = symbolTable[hash_value];

    while(node != NULL){
        if(strcmp(node->name,str)==0)
            return node->address;
        node = node->next;
    }
    return -1;
}

int findFormat(char* mnemonic){
    int hash_value, flag=0, four=0;
    
    if(mnemonic[0] == '+') {
        four=1; //+붙으면 4형식
        sscanf(mnemonic,"+%s",mnemonic);        //+빼고 다시 저장
    }
    hashNode* tmp = (hashNode*)malloc(sizeof(hashNode));
    hash_value = findHashValue(mnemonic);
    tmp = hashTable[hash_value];
    while(tmp != NULL){
        if(strcmp(tmp->mnemonic, mnemonic)==0){
            flag=1;
            if(strcmp(tmp->format,"1")==0) return 1;
            else if(strcmp(tmp->format,"2")==0) return 2;
            else if(strcmp(tmp->format,"3/4")==0 && four==0) return 3;
            else if(strcmp(tmp->format,"3/4")==0 && four==1) return 4;
        }
        tmp = tmp->next;
    }

    if (flag == 0) return -1;
    return 0;
}

int ChangeHexa(char* tmp, int start, int len) {
    //int l=strlen(tmp);
    int cnt = 1, value = 0;
    int i;
    for (i = start + len - 1;i >= start;i--) {
        if (tmp[i] >= '0'&&tmp[i] <= '9') {
            value += (tmp[i] - '0')*cnt;
        }
        else if (tmp[i] >= 'A'&&tmp[i] <= 'F') {
            value += (tmp[i] - 'A' + 10)*cnt;
        }
        cnt *= 16;
    }
    return value;
}

int loader(char* prog1, char* prog2, char* prog3, int count) { //에러 발생 시 -1 return
    int l; //file 길이
    int add[3] = { 0, };
    cs_address = prog_address;
    run_address = -1;
    freeEST();
    e_start = end = prog_address;
    if (count == 1) { //로딩할 파일이 1개인 경우
        //obj파일인지 확인
        l = strlen(prog1);
        if (strcmp(prog1 + l - 4, ".obj") != 0) { //아니면 종료
            printf("Check the file format.\n");
            return -1;
        }
        //Lpass1
        if (Lpass1(prog1) == -1) { freeEST(); return -1; }
        add[0] = cs_address;
        cs_address += control_len; end = cs_address;
        
        //Lpass2
        if (Lpass2(prog1, add[0]) == -1) { freeEST(); return -1; }
    }
    else if (count == 2) { //로딩할 파일이 2개인 경우
        //obj파일인지 확인
        l = strlen(prog1);
        if (strcmp(prog1 + l - 4, ".obj") != 0) { //아니면 종료
            printf("Check the file format.\n");
            return -1;
        }
        l = strlen(prog2);
        if (strcmp(prog2 + l - 4, ".obj") != 0) { //아니면 종료
            printf("Check the file format.\n");
            return -1;
        }
        //Lpass1
        if (Lpass1(prog1) == -1) { freeEST(); return -1; }
        add[0] = cs_address;
        cs_address += control_len; end = cs_address;
        if (Lpass1(prog2) == -1) { freeEST(); return -1; }
        add[1] = cs_address;
        cs_address += control_len; end = cs_address;

        //Lpass2
        if (Lpass2(prog1, add[0]) == -1) { freeEST(); return -1; }
        if (Lpass2(prog2, add[1]) == -1) { freeEST(); return -1; }

    }
    else { //로딩할 파일이 3개인 경우
        //obj파일인지 확인
        l = strlen(prog1);
        if (strcmp(prog1 + l - 4, ".obj") != 0) { //아니면 종료
            printf("Check the file format.\n");
            return -1;
        }
        l = strlen(prog2);
        if (strcmp(prog2 + l - 4, ".obj") != 0) { //아니면 종료
            printf("Check the file format.\n");
            return -1;
        }
        l = strlen(prog3);
        if (strcmp(prog3 + l - 4, ".obj") != 0) { //아니면 종료
            printf("Check the file format.\n");
            return -1;
        }
        //Lpass1
        if (Lpass1(prog1) == -1) { freeEST(); return -1; }
        add[0] = cs_address;
        cs_address += control_len; end = cs_address;
        if (Lpass1(prog2) == -1) { freeEST(); return -1; }
        add[1] = cs_address;
        cs_address += control_len; end = cs_address;
        if (Lpass1(prog3) == -1) { freeEST(); return -1; }
        add[2] = cs_address;
        cs_address += control_len; end = cs_address;

        //Lpass2
        if (Lpass2(prog1, add[0]) == -1) { freeEST(); return -1; }
        if (Lpass2(prog2, add[1]) == -1) { freeEST(); return -1; }
        if (Lpass2(prog3, add[2]) == -1) { freeEST(); return -1; }
    }
    printEST();
    return 0;
}

int Lpass1(char* prog) {
    FILE* fp = fopen(prog, "r");
    char command[500];
    char rT; //record type
    int l; //command의 길이
    char progName[7], symbName[7], tmp[7];
    int progStart, progLength, symbAddr;
    int i;

    if (fp == NULL) { printf("ERROR! FILE DOSEN'T EXIST!!\n"); return -1; }

    while (fgets(command, 500, fp) != NULL) {
        rT = command[0];
        l = strlen(command);
        if (rT == '.') continue; //주석인 경우
        if (command[l - 1] == '\n') { command[l - 1] = '\0';l--; }
        if (rT == 'R' || rT == 'T' || rT == 'M')continue; //R,T,M record
        else if (rT == 'H') { //H record
            sscanf(command, "%*c %06s %06X %06X", progName, &progStart, &progLength);
            control_len = progLength;
            if (addEST(progName, 0, progStart, progLength) == -1) {
                printf("Error Line : %s\n", command); return -1; }
        }
        else if (rT == 'D') { //D record
            for (i = 1;i<l;i += 12) {
                strncpy(symbName, command + i, 6); symbName[6] = '\0';
                strncpy(tmp, command + i + 6, 6);  tmp[6] = '\0';
                symbAddr = ChangeHexa(tmp, 0, 6);
                if (addEST(symbName, 1, symbAddr, 0) == -1) { printf("Error Line : %s\n", command); return -1; }

            }
        }
        else if (rT == 'E') {
            continue;
        } //E record
        else { printf("Error Line : %s\n", command); return -1; } //다른 이상한 내용이 있는 경우
    }
    fclose(fp);
    return 0;
}

int Lpass2(char* prog, int addr) {
    FILE *fp = fopen(prog, "r");
    char rT, command[500];
    int l;
    int num1, num2, num3;
    char tmp[10];
    int i, j;
    int value;
    int address;
    int ref[100] = { 0 };
    
    ref[1]=addr;
    while (fgets(command, 500, fp) != NULL) {
        rT = command[0];
        if (rT == '.') continue; //주석
        l = strlen(command);
        if (command[l - 1] == '\n') { command[l - 1] = '\0';l--; }

        if (rT == 'H' || rT == 'D')continue; //H,D Record
        else if (rT == 'R') {    //R Record
            for (i = 1;i<l;i += 8) {
                num1 = ChangeHexa(command, i, 2);
                strncpy(tmp, command + i + 2, 6);
                tmp[6] = '\0';
                for (j = 5;j >= 0;j--) {
                    if (tmp[j] == '\0') {
                        tmp[j] = ' ';continue;
                    }
                    break;
                }
                num2 = matchEST(tmp);
                ref[num1] = num2;
            }
        }
        else if (rT == 'T') {    //T Record
            num1 = ChangeHexa(command, 1, 6);
            num2 = ChangeHexa(command, 7, 2);
            j = 0;
            for (i = 9;i<l;i += 2) {
                num3 = ChangeHexa(command, i, 2);
                data[addr + j + num1] = num3;
                j++;
            }
        }
        else if (rT == 'M') {    //M Record
            num1 = ChangeHexa(command, 1, 6);
            num2 = ChangeHexa(command, 7, 2);
            if(command[10]=='\0') num3=1;
            else num3 = ChangeHexa(command, 10, 2);
            address = addr + num1;
            if (num2 == 5) {
                j = data[address] & 15;
                value = (j << 16) + (data[address + 1] << 8) + data[address + 2];
                if (command[9] == '+')value += ref[num3];
                else if (command[9] == '-')value -= ref[num3];
                else value+=ref[num3];

                value = value & (16 * 16 * 16 * 16 * 16 * 16 - 1);
                data[address] = data[address] - j + (value >> 16);
                data[address + 1] = (255 & (value >> 8));
                data[address + 2] = (255 & value);

            }
            else if (num2 == 6) {
                value=(data[address]<<16)+(data[address+1]<<8)+data[address+2];
                if (command[9] == '+')value += ref[num3];
                else if (command[9] == '-')value -= ref[num3];
                value = value & (16 * 16 * 16 * 16 * 16 * 16 - 1);
                data[address] = (255 & (value >> 16));
                data[address + 1] = (255 & (value >> 8));
                data[address + 2] = (255 & value);
            }
            else { printf("Error Line : %s\n", command); return -1; }
        }
        else if (rT == 'E') {
            if (l == 7) {
                num1 = ChangeHexa(command, 1, 6);
                e_start = addr + num1;
            }
            break;
        }
    }
    fclose(fp);
    return 0;
}

void printEST() {
    ESTAB* p;
    int total = 0;
    printf("control\tsymbol\taddress\tlength\n");
    printf("section\tname\t\n");
    printf("------------------------------------\n");
    p = e_root;
    while (p != NULL) {
        if (p->type == 0) { //control section인 경우
            printf("%s\t\t%04X\t%04X\n", p->name, p->addr, p->length);
            total += (p->length);
        }
        else //symbol인 경우
            printf("%15s\t%04X\t\n", p->name, p->addr);
        p = p->next2;
    }
    printf("------------------------------------\n");
    printf("\t  total length\t%04X\n", total);
}

void freeEST() {
    int i;
    ESTAB* p;
    e_root = e_end = NULL;
    for (i = 0;i<20;i++) {
        if (e_table[i] == NULL)continue;
        while (e_table[i] != NULL) {
            p = e_table[i];
            e_table[i] = e_table[i]->next;
            free(p);
        }
    }
}

int addEST(char* name, int type, int num1, int num2) {
    int hash_value = findHashValue(name);
    ESTAB *tmp, *p;
    tmp = (ESTAB*)malloc(sizeof(ESTAB));
    strcpy(tmp->name, name);
    tmp->type = type;
    tmp->addr = num1 + cs_address;
    tmp->length = num2;
    tmp->next = tmp->next2 = NULL;

    if (e_table[hash_value] == NULL) {
        e_table[hash_value] = tmp;
        if (e_root == NULL)
            e_root = e_end = tmp;
        else {
            e_end->next2 = tmp;
            e_end = tmp;
        }
    }
    else {
        p = e_table[hash_value];
        while (1) {
            if (strcmp(tmp->name, p->name) == 0) return -1; //symbol이 중복된 경우
            if (p->next == NULL) break;
            else p = p->next;
        }
        p->next = tmp;
        e_end->next2 = tmp;
        e_end = tmp;
    }
    return 0;
}

int matchEST(char* symbol) {
    int hash_value = findHashValue(symbol);
    ESTAB* p;
    for (p = e_table[hash_value];p != NULL;p = p->next) {
        if (strcmp(p->name, symbol) == 0)
            return p->addr;
    }
    return -1;
}

void printFlag(int pA, int pX, int pL, int pPC, int pB, int pS, int pT) {
    printf("\tA : %06X  X : %06X\n", pA, pX);
    printf("\tL : %06X PC : %06X\n", pL, pPC);
    printf("\tB : %06X  S : %06X\n", pB, pS);
    printf("\tT : %06X\n", pT);
}

void run() {
    int i, j;
    int num1, num2, op, t, t1, t2;
    int temp_pc;
    int xbpe,e,ch;
    int value1,value0,value1_e,value0_e;
    int pA, pX, pL, pPC, pB, pS, pT;

    if (run_address==-1) {    // 처음 시작시 register들 set
        run_address = prog_address;
        A = X = pc = B = SS = TT = 0;
        pc = e_start;
        L = end;
        r_flag = 0;
    }
    i = run_address;
    while (i>=prog_address && i<end) {    //프로그램 끝까지 반복
        pA = A; pX = X; pL = L; pPC = pc; pB = B; pS = SS; pT = TT;
        
        if (i<e_start) {
            if (bp_flag[i]==1) {    //breakpoint인 경우
                printFlag(pA, pX, pL, pPC, pB, pS, pT); printf("\t\t    Stop at checkpoint[%X]\n", i);
                run_address=i+1; return;
            }
            i++;
            continue;
        }
        op = data[i]-data[i]%4;
        t = data[i]%4; //ni
        
        xbpe = data[i+1]/16;
        e = xbpe%2;
        ch = data[i+1]>>4;
        value1 = value0 = value1_e = value0_e = 0;

        if(e==1){ //flag가 1이면 value1 0이면 value0
            value1_e=((data[i+1]&15)<<16)+(data[i+2]<<8)+data[i+3];
            if(t==1) //immediate
                value0_e=value1_e;
            else if(t==2) { //indirect
                value1_e=(data[value1_e]<<16)+(data[value1_e+1]<<8)+data[value1_e+2];
                value0_e=(data[value1_e]<<16)+(data[value1_e+1]<<8)+data[value1_e+2];
            }
            else if(t==3){ //simple
                value0_e=(data[value1_e]<<16)+(data[value1_e+1]<<8)+data[value1_e+2];
            }
        }
        else{ //e==0
            value1=((data[i+1]&15)<<8)+data[i+2];
            if(ch&4)value1+=B;
            else if(ch&2){
                if((value1>>11)&1){
                    value1=(~value1)+1;
                    value1=value1&(256*16-1);
                    value1=-value1;
                }
                value1=value1+pc+3;
            }
            if(ch&8) value1+=X;
            if(t==1)//immediate
                value0=value1;
            else if(t==2) { //indirect
                value1=(data[value1]<<16)+(data[value1+1]<<8)+data[value1+2];
                value0=(data[value1]<<16)+(data[value1+1]<<8)+data[value1+2];
            }
            else if(t==3){ //simple
                value0=(data[value1]<<16)+(data[value1+1]<<8)+data[value1+2];
            }
        }
        switch (op) {                //해당 opcode에 따라 다른 명령 수행
        case 180:    //CLEAR
            num1=data[i+1]>>4;
            if (num1==0) A=0;
            else if (num1==1) X=0;
            else if (num1==2) L=0;
            else if (num1==3) B=0;
            else if (num1==4) SS=0;
            else if (num1==5) TT=0;
            pc=i+2; temp_pc=pc;
            break;

        case 40:    //COMP
            if(e==1){
                pc=i+4;
                num1=value0_e;
            }
            else{
                pc=i+3;
                num1=value0;
            }
            if (A==num1) r_flag=1;
            else if (A<num1) r_flag=2;
            else r_flag=3;
            temp_pc=pc;
            break;

        case 160:    //COMPR
            num1=data[i+1]>>4; num2=data[i+1]&15;
            
            t1=0; t2=0;
            if (num1==0) t1=A;
            else if (num1==1) t1=X;
            else if (num1==2) t1=L;
            else if (num1==3) t1=B;
            else if (num1==4) t1=SS;
            else if (num1==5) t1=TT;
            else if (num1==8) t1=pc;

            if (num2==0) t2=A;
            else if (num2==1) t2=X;
            else if (num2==2) t2=L;
            else if (num2==3) t2=B;
            else if (num2==4) t2=SS;
            else if (num2==5) t2=TT;
            else if (num2==8) t2=pc;

            if (t1==t2) r_flag=1;
            else if (t1<t2) r_flag=2;
            else r_flag=3;
            pc=i+2; temp_pc=pc;
            break;

        case 60:    //J
            if (e==1) { pc=i+4;num1=value1_e;}
            else {pc=i+3; num1=value1;}
            temp_pc=pc; pc=num1;
            break;

        case 48:    //JEQ
            if (e==1) pc=i+4;
            else pc=i+3;
            if (r_flag==1) {
                if (e==1) num1=value1_e;
                else num1=value1;
                temp_pc=pc; pc=num1;
            }
            else temp_pc=pc;
            break;

        case 56:    //JLT
            if (e==1)pc=i+4;
            else pc=i+3;
            if (r_flag==2) {
                if (e==1) num1=value1_e;
                else num1=value1;
                temp_pc=pc; pc=num1;
            }
            else temp_pc=pc;
            break;

        case 72:    //JSUB
            if (e==1){pc=i+4; num1=value1_e;}
            else {pc=i+3; num1=value1;}
            temp_pc = pc; L = pc; pc = num1;
            break;

        case 0:        //LDA
            if (e==1){pc=i+4; num1=value0_e;}
            else {pc=i+3; num1=value0;}
            A=num1; temp_pc=pc;
            break;

        case 104:    //LDB
            if (e==1){pc=i+4; num1=value0_e;}
            else {pc=i+3; num1=value0;}
            B=num1; temp_pc=pc;
            break;

        case 80:    //LDCH
            if (e==1){pc=i+4; num1=value0_e;}
            else {pc=i+3;num1=value0;}
            A=A-(A&255)+(num1>>16); temp_pc=pc;
            break;

        case 116:    //LDT
            if (e==1){pc=i+4; num1=value0_e;}
            else {pc=i+3;;num1=value0;}
            TT=num1; temp_pc=pc;
            break;

        case 4:    //LDX
            if (e==1){pc=i+4; num1=value0_e;}
            else {pc=i+3; num1=value0;}
            X=num1; temp_pc=pc;
            break;
            
        case 12:    //STA
            if (e==1){pc=i+4;num1=value1_e;}
            else {pc=i+3;num1=value1;}
            data[num1]=A>>16; data[num1+1]=(A>>8)&255; data[num1+2]=A&255;
            temp_pc=pc;
            break;

        case 84:    //STCH
            if (e==1){pc=i+4;num1=value1_e;}
            else {pc=i+3;num1=value1;}
            data[num1] = A & 255; temp_pc = pc;
            break;

        case 20:    //STL
            if (e==1){pc=i+4;num1=value1_e;}
            else {pc=i+3;num1=value1;}
            data[num1] = L >> 16; data[num1 + 1] = (L >> 8) & 255; data[num1 + 2] = L & 255;
            temp_pc=pc;
            break;

        case 16:    //STX
            if (e==1){pc=i+4;num1=value1_e;}
            else {pc=i+3; num1=value1;}
            data[num1]=X>>16; data[num1+1]=(X>>8)&255; data[num1+2]=X&255;
            temp_pc=pc;
            break;

        case 184:    //TIXR
            num1=data[i+1]>>4; pc=i+2;
            t1=0;
            if (num1==0) t1=A;
            else if (num1==1) t1=X;
            else if (num1==2) t1=L;
            else if (num1==3) t1=B;
            else if (num1==4) t1=SS;
            else if (num1==5) t1=TT;
            else if (num1==8) t1=pc;
            X++;
            if (X==t1) r_flag=1;
            else if (X<t1) r_flag=2;
            else r_flag=3;
            temp_pc=pc;
            break;
            ////////////////////////////
        case 224:    //TD
            if (e==1) pc=i+4;
            else pc=i+3;
            r_flag=2; temp_pc=pc;
            break;

        case 216:    //RD
            if (e==1) pc=i+4;
            else pc=i+3;
            A=0; temp_pc=pc;
            break;

        case 220:    //WD
            if (e==1) pc=i+4;
            else pc=i+3;
            temp_pc=pc;
            break;

        case 76:    //RSUB
            if (e==1){pc=i+4;num1=value1_e;}
            else {pc=i+3;num1=value1;}
            temp_pc=pc; pc=L;
            break;

        default:
            pc++;
        }
        for (j = i;j<temp_pc;j++) {
            if (bp_flag[j]==1) {                //breakpoint인 경우
                printFlag(pA, pX, pL, pPC, pB, pS, pT); printf("\t\t    Stop at checkpoint[%X]\n", j);
                run_address = pc; return;
            }
        }
        i=pc;
    }
    printFlag(A, X, L, pc, B, SS, TT); printf("\t\t    End Program\n"); run_address = -1; return;
}

void breakPoint(int addr) {
    int i;
    if (addr==-2) { //bp clear인 경우
        for(i=0;i<bp_cnt;i++) bp_flag[bp[i]]=0;
        bp_cnt=0; printf("\t     [");
        printf(COLOR_GREEN "ok" COLOR_RESET "] clear all breakpoints\n");
    }
    else if (addr==-1) {    //bp인 경우
        printf("\t     breakpoint\n");
        printf("\t     ----------\n");
        for (i = 0;i<bp_cnt;i++) {
            printf("\t     %X\n", bp[i]);
        }
    }
    else {    //bp address인 경우
        if (bp_flag[addr] != 1) {//bp address
            bp_flag[addr] = 1; bp[bp_cnt++] = addr;
            printf("\t     [");
            printf(COLOR_GREEN "ok" COLOR_RESET "] create breakpoint %x\n", addr);
        }
        else
            printf("\tThe breakpoint you just entered, already exist.\n");
    }
    return;
}
