#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <ctype.h>

#define COLOR_GREEN "\x1b[32m"
#define COLOR_RESET "\x1b[0m"

typedef struct hisNode{ //history 를 linkedlist로 구현함
    char input[100];
    struct hisNode* next;
}hisNode;
hisNode* hisHead;
hisNode* hisTail;

typedef struct hashNode { //opcode.txt의 정보를 넣기 위한 hash Table
    int opcode;
    char mnemonic[10];
    char format[5];
    struct hashNode* next;
}hashNode;
hashNode* hashTable[20];

typedef struct symbolNode {
    char name[10];
    int address;
    struct symbolNode* next;
}symbolNode;
symbolNode* symbolTable[20];

typedef struct objectNode {
    unsigned char name[100];
    int check, format;
}objectNode;
objectNode* objectCode;

typedef struct operand{
    int mode;
    int addr;
}Opr;
Opr operandMode(char* str);

typedef struct _ESTAB{
    int type; //control sectoin이면 0 symbol이면 1
    char name[20];
    int addr;
    int length;
    struct _ESTAB* next;
    struct _ESTAB* next2;
}ESTAB;
ESTAB* e_root;
ESTAB* e_end;
ESTAB* e_table[20];

int address_current = 0; // 현재 가리키는 주소
unsigned char data[1048576] = {0,}; // 16 X 65536 + 1 // 1MB의 메모리를 할당
int symbol_cnt, line_cnt; // symbol과 line의 개수를 세주는 변수
int* line; // assemble 시 Location을 저장할 배열
char pName[7]; // asm파일 첫번째 줄의 이름

int prog_address = 0;                    //loader 또는 run 명령어를 수행할 때 시작 주소
int cs_address;                          //cs_address 주소
int control_len;                         //control section의 길이
int e_start;                             //실행 가능한 첫 주소
int run_address = 0;                     //run 시작 주소
int bp[100],bp_cnt,bp_flag[1048576];     //BreakPoint
int A,X,L,B,SS,TT,pc,r_flag;             //레지스터
int end;                                 //프로그램 끝

int readOpcodeFile(void); // opcode.txt 파일을 읽은 후, hashTable에 알맞게 저장
int commandNumber(char* command); // command를 받아 어느 명령을 수행할지 0~9를 return 하여 결정
int checkCommand(char* input); // command 입력 형식 쉽게 판별하기 위한 함수
void help(void); //help기능을 구현한 함수로, 명령어 목록을 출력
void dir(void); //dir기능을 구현한 함수
void quit(void); //프로그램에서 동적할당 된 memory 모두 free 시키고 프로그램 종료
void history(void); //history 기능을 구현한 함수
void historyLink(char* input); // history link에 사용자 입력 추가하는 함수
void dump(int address_start, int address_end); // dump 기능을 구현한 함수
int checkHexa(char* check, int flag); // 16진수가 필요한 명령어가 올바른지 판별 도와주는 함수
void edit(int address, int value); // edit 기능을 구현한 함수
void fill(int address_start, int address_end, int value); //fill 기능을 구현한 함수
void reset(void); // reset 기능을 구현한 함수
int opcode(char* mnemonic, int key); // opcode 기능을 구현한 함수
int checkMnemonic(char* check); // Mnemonic을 대문자 이외의 input을 거르기 위해 구현한 함수
int findHashValue(char* mnemonic); //mnemonic의 hash value를 구하기 위한 함수
void opcodelist(void); //opcodelist를 구현한 함수

void assemble(char* filename); // assemble 기능을 구현한 함수
int pass1(char* filename);
int pass2(char* filename);
int symbolAdd(char* str, int Loc);
void type(char* filename); // type 기능을 구현한 함수
void symbol(void); // symbol 기능을 구현한 함수
int findReg(char* str);
int findFormat(char* str);
int findSymbol(char* str);

int ChangeHexa(char* tmp, int start, int len);
int loader(char* prog1, char* prog2, char* prog3, int count);
int Lpass1(char* prog);
int Lpass2(char* prog, int addr);
void printEST(void);
void freeEST(void);
int addEST(char* name, int type, int num1, int num2);
int matchEST(char* symbol);
void printFlag(int pA, int pX, int pL, int pPC, int pB, int pS, int pT);
void run(void);
void breakPoint(int addr);
